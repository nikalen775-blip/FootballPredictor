package com.example.footballpredictor

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.time.LocalDate

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    private lateinit var key: EditText
    private lateinit var date: EditText
    private lateinit var league: Spinner
    private lateinit var result: TextView
    private val leagues = linkedMapOf(
        "Όλα" to null, "Ελλάδα Super League" to 197, "Premier League" to 39,
        "La Liga" to 140, "Serie A" to 135, "Bundesliga" to 78
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        fun label(t:String)=TextView(this).apply{ text=t; textSize=16f; setPadding(0,10,0,4)}
        box.addView(TextView(this).apply{ text="⚽ Football Predictor V1"; textSize=25f })
        box.addView(label("API-Football API Key"))
        key=EditText(this).apply{ hint="Βάλε το API key σου"; inputType=129 }
        box.addView(key)
        box.addView(label("Ημερομηνία"))
        date=EditText(this).apply{ setText(LocalDate.now().toString()); hint="YYYY-MM-DD" }
        box.addView(date)
        box.addView(label("Πρωτάθλημα"))
        league=Spinner(this)
        league.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, leagues.keys.toList())
        box.addView(league)
        val b=Button(this).apply{ text="Φόρτωση αγώνων & προβλέψεων" }
        box.addView(b)
        result=TextView(this).apply{ textSize=15f; setPadding(0,20,0,0)}
        box.addView(ScrollView(this).apply{ addView(result) }, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(box)
        b.setOnClickListener{ load() }
    }

    private fun load() {
        val apiKey=key.text.toString().trim()
        if(apiKey.isEmpty()){ result.text="Βάλε το API key."; return }
        val d=date.text.toString().trim()
        val lid=leagues[league.selectedItem.toString()]
        CoroutineScope(Dispatchers.IO).launch {
            try {
                var url="https://v3.football.api-sports.io/fixtures?date=$d&timezone=Europe/Athens"
                if(lid!=null) url+="&league=$lid"
                val req=Request.Builder().url(url).addHeader("x-apisports-key",apiKey).build()
                val json=JSONObject(client.newCall(req).execute().body!!.string())
                val arr=json.optJSONArray("response")
                val sb=StringBuilder("Αποτελέσματα για $d\n\n")
                if(arr==null || arr.length()==0) sb.append("Δεν βρέθηκαν αγώνες.")
                else for(i in 0 until minOf(arr.length(),10)){
                    val f=arr.getJSONObject(i)
                    val teams=f.getJSONObject("teams")
                    val h=teams.getJSONObject("home").getString("name")
                    val a=teams.getJSONObject("away").getString("name")
                    val id=f.getJSONObject("fixture").getLong("id")
                    sb.append("⚽ $h – $a\n")
                    val pr=prediction(id,apiKey)
                    if(pr!=null) {
                        val p=pr.optJSONObject("predictions")
                        val pct=p?.optJSONObject("percent")
                        sb.append("Over/Under: ${p?.optString("under_over","—")}\n")
                        sb.append("1: ${pct?.optString("home","—")}  X: ${pct?.optString("draw","—")}  2: ${pct?.optString("away","—")}\n")
                        sb.append("Advice: ${p?.optString("advice","—")}\n")
                    } else sb.append("Δεν υπάρχει διαθέσιμη πρόβλεψη API.\n")
                    sb.append("\n")
                }
                withContext(Dispatchers.Main){ result.text=sb.toString() }
            } catch(e:Exception){ withContext(Dispatchers.Main){ result.text="Σφάλμα: ${e.message}" } }
        }
    }

    private fun prediction(id:Long, key:String): JSONObject? {
        val req=Request.Builder().url("https://v3.football.api-sports.io/predictions?fixture=$id")
            .addHeader("x-apisports-key",key).build()
        val j=JSONObject(client.newCall(req).execute().body!!.string())
        return j.optJSONArray("response")?.optJSONObject(0)
    }
}
