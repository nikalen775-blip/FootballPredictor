# Football Predictor Android V1

Πρώτη native Android έκδοση:
- Fixtures ανά ημερομηνία
- Ελλάδα Super League, Premier League, La Liga, Serie A, Bundesliga
- API-Football `/fixtures` και `/predictions`
- Over/Under prediction από API και 1/X/2 probabilities

## Επόμενα
- ασφαλής αποθήκευση API key
- δικό μας Poisson μοντέλο
- Over/Under 1.5/2.5/3.5
- BTTS
- backtesting
- basketball


## Cloud build
Το project περιλαμβάνει GitHub Actions workflow για αυτόματο debug APK build.
